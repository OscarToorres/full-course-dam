// 
// Decompiled by Procyon v0.5.36
// 

package teoria.capitulo07;

import misClases.teoria.CMatrizString;

class CApMatrizString
{
    public static void main(final String[] args) {
        final CMatrizString matriz = new CMatrizString();
        matriz.crea();
        matriz.llena();
        matriz.amosa();
    }
}
