// 
// Decompiled by Procyon v0.5.36
// 

package teoria.capitulo07;

import misClases.teoria.CMatrizEnteros;

class CApMatrizEnteros
{
    public static void main(final String[] args) {
        final CMatrizEnteros matriz = new CMatrizEnteros();
        matriz.crea();
        matriz.llena();
        matriz.amosa();
    }
}
