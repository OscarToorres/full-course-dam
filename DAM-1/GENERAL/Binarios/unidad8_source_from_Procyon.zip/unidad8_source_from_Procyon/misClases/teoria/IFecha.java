// 
// Decompiled by Procyon v0.5.36
// 

package misClases.teoria;

public interface IFecha
{
    public static final int DIA_DEL_MES = 5;
    public static final int MES_DEL_ANHO = 2;
    public static final int ANHO = 1;
    
    int dia();
    
    int mes();
    
    int anho();
}
