package practicas.ejem02;

public class COposicion {
    private CAspirante[] oposicion;
    private int total;

    public COposicion() {
        oposicion = new CAspirante[5];
        total = 0;
    }

    public void llenar() {
        oposicion[0] = new CAspirante(100, "Marta Mart�nez", 35.95F);
        oposicion[1] = new CAspirante(200, "Marcos Arias", 45.75F);
        oposicion[2] = new CAspirante(300, "Ux�a Novoa", 38.25F);
        oposicion[3] = new CAspirante(400, "Joan Barcel", 29.85F);
        oposicion[4] = new CAspirante(500, "Petra Rai�a", 26.15F);
        total = 5;
    }

    public void vaciar() {
        total = 0;
    }

    private int dameIndice(int cla) {
        int i;

        i = 0;
        while (i < total)
            if (oposicion[i].getClave() == cla)
                return i;
            else
                i++;
        return -1;
    }

    private void elimina(int i) {
        // se debe implementar
    }

    public void eliminarAspirante(int cla) {
        // se debe implementar
    }

    public void mostrar() {
        int i;

        if (total == 0)
            System.out.println("Oposici�n VACIA");
        else {
            mostrarCabecera();
            for (i = 0; i < total; i++)
                oposicion[i].mostrar();
        }
    }

    private void mostrarCabecera() {
        System.out.println("CLAVE" + "\tNOMBRE  " + "\tTASAS");
        System.out.println("=====" + "\t======  " + "\t=====");
    }

    private void menu() {
        System.out.println("\n  M E N U - 2");
        System.out.println("  ===========");
        System.out.println("1.- LLENAR Oposici�n");
        System.out.println("2.- VACIAR Oposici�n");
        System.out.println("3.- MOSTRAR Oposici�n");
        System.out.println("4.- ELIMINAR Aspirante");
        System.out.println("5.- FINAL");
        System.out.print("Pulsa opci�n: ");
    }

    public int dameOpcion() {
        int opcion;

        menu();
        opcion = Leer.datoInt();
        System.out.println();
        return opcion;
    }
}
