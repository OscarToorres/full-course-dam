// 
// Decompiled by Procyon v0.5.36
// 

package misClases.teoria;

class CPunto
{
    private double x;
    private double y;
    
    public CPunto(final double cx, final double cy) {
        this.x = cx;
        this.y = cy;
    }
}
