package Practica_08_Ejercicio1;

public class MenusApp {

    public static void main(String[] args) {
        ControladorMenus controlador = new ControladorMenus();
        controlador.controlador();
    }
}