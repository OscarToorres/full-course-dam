public class VentanaFlowApp {

    public static void main(String[] args) {
        VentanaFlowLayout miVentana = new VentanaFlowLayout();
        miVentana.setVisible(true);
    }

}
