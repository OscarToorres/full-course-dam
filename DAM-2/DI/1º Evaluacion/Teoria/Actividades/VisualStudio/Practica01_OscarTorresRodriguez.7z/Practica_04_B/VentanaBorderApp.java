public class VentanaBorderApp {

    public static void main(String[] args) {
        VentanaBorderLayout miVentana = new VentanaBorderLayout();
        miVentana.setVisible(true);
    }
}