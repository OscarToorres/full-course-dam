package Practica_07_B;

public class EdicionTextoApp {

    public static void main(String[] args) {
        ControladorEdicionTexto controlador = new ControladorEdicionTexto();
        controlador.ventExec();

    }
}