package Practica_07;

public class ColoresApp {
    public static void main(String[] args) {
        ControladorColores cc = new ControladorColores();
        cc.ventExec();
    }
}