public class AnalizarFraseApp {

    public static void main(String[] args) {
        AnalizarFraseLayout fraseLayout = new AnalizarFraseLayout();
        fraseLayout.setVisible(true);
    }

}
