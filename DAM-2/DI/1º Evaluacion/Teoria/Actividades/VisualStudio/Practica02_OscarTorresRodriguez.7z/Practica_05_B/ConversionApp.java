package Practica_05_B;

public class ConversionApp {
    public static void main(String[] args) {

        ConversionLayout conversion = new ConversionLayout();
        conversion.setVisible(true);
    }
}