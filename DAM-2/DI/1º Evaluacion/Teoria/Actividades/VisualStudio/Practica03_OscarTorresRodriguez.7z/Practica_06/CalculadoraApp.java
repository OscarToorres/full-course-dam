package Practica_06;

public class CalculadoraApp {
    
    public static void main (String [] args) { 
        CalculadoraDiseño diseño = new CalculadoraDiseño();
        diseño.setVisible(true);
    }  
}