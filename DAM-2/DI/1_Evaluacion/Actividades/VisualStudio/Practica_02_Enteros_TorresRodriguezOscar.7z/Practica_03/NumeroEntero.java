
public class NumeroEntero {

    //Drcalaracion de Objetos

    private int valor;

    //Constructores

    public NumeroEntero() {
    }

    public NumeroEntero(int valor) {
        this.valor = valor;
    }

    //Getters and Setters

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    
    
}
